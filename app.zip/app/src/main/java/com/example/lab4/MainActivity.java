package com.example.lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void MainWork(View v) {
        Functions hd = new Functions();
        hd.hide(v);
        double x;
        try {
            EditText a = (EditText) findViewById(R.id.a);
            EditText b = (EditText) findViewById(R.id.b);
            EditText E = (EditText) findViewById(R.id.E);
            EditText res = (EditText)findViewById(R.id.result);

            double num_a = Double.parseDouble(a.getText().toString());
            double num_b = Double.parseDouble(b.getText().toString());
            double num_E = Double.parseDouble(E.getText().toString());
            double f0_a = Math.sin(num_a + Math.PI/2)*Math.sin(num_a + Math.PI/2) - (num_a*num_a/4);
            double f0_b = Math.sin(num_b + Math.PI/2)*Math.sin(num_b + Math.PI/2) - (num_b*num_b/4);
            double f1_b = 2*Math.sin(num_b + Math.PI/2)*Math.cos(num_b+Math.PI/2) - (num_b/2);
            double f2_b = 2*Math.cos(num_b+Math.PI/2)*Math.cos(num_b+Math.PI/2) - 2*Math.sin(num_b+Math.PI/2)*Math.sin(num_b+Math.PI/2) - 0.5;
            int k = 0;
            if (f0_a*f0_b < 0) {
                res.setText("Введіть інші числа");
            } else {
                if(Math.abs(num_b-num_a) < num_E) {
                    if (f0_b*f2_b > 0) {
                        do {
                            x = num_b - (f0_b / f1_b);
                            k = k + 1;
                            num_b = x;
                        }while(Math.abs(x-num_b)>=num_E);
                        String res0 = String.format("%.2f",x);
                        String k0 = Integer.toString(k);
                        res.setText("x =" + res0 + " "+"k = "+k0);
                    }else {
                        double z = num_b;
                        num_b = num_a;
                        num_a=z;
                        do {
                            x = num_b - (f0_b / f1_b);
                            k = k + 1;
                            num_b = x;
                        }while(Math.abs(x-num_b)>=num_E);
                        String res0 = String.format("%.2f",x);
                        String k0 = Integer.toString(k);
                        res.setText("x =" + res0 +" "+ "k = "+k0);
                    }
                }else{
                    x =(num_a+num_b/2);
                    String res0 = String.format("%.2f",x);
                    String k0 = Integer.toString(k);
                    res.setText("x =" + res0 +" "+ "k = "+k0);
                }
            }
        } catch(NumberFormatException e){
            TextView res = (TextView) findViewById(R.id.result);
            res.setText("Введіть усі числа");
        }
    }
}
