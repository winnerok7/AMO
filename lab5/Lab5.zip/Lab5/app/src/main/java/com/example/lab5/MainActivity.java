package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void MainButton(View v) {
        Functions hd = new Functions();
        hd.hide(v);
        TextView res = (TextView) findViewById(R.id.result);
        TextView matrix0 = (TextView) findViewById(R.id.matrix);
        TextView koef_b = (TextView) findViewById(R.id.b_koeff);

        double[][] m0 = new double[][] {	{1.84, 2.25, 2.58},
                {2.32, 2.00, 2.82},
                {1.83, 2.06, 2.24}};
        double[] v0 = new double[] {-6.09, -6.96, -5.52};

        Matrix matrix = new Matrix(m0);
        Vector koef = new Vector(v0);

        String fnll = String.valueOf(matrix);
        matrix0.setText(fnll);
        String fnll1 = String.valueOf(koef);
        koef_b.setText(fnll1);

        Vector result0 = GaussJordano.solve(matrix, koef, 4);
        String result1 = String.valueOf(result0);
        res.setText(result1);
    }
}
